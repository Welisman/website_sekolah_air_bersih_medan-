const UserContact = () => {
    return (
        <div>
            <h1>Contact</h1>
        </div>
    )
}

export default UserContact;