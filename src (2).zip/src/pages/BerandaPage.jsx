import React from "react";
import KataSambutan from "../details/KataSambutan";
import VisiMisi from "../details/VisiMisi";
import Struktur from "../details/Struktur";
import ImageCarousel from "../details/carousel";
const BerandaPage = () => {
    return (
        <div>
            <ImageCarousel/>
            <KataSambutan/>
            <VisiMisi/>
            {/* <Events/> */}
            <Struktur/>
        </div>
    )
}

export default BerandaPage;