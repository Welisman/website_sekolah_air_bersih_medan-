import React from 'react';
import Dashboard from './pages/Dashboard';
import ErrorBoundary from './error/ErrorBoundary';

const App = () => {
  return (
    <ErrorBoundary>
      <Dashboard />
    </ErrorBoundary>
  );
};

export default App;
