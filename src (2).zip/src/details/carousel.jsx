import { Swiper, SwiperSlide } from "swiper/react";
import { Navigation, Pagination, Autoplay } from "swiper/modules";
import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/pagination";
import slide1 from "../../assets/carousel/slide1.jpg";
import slide2 from "../../assets/carousel/slide2.jpg";

const ImageCarousel = () => {
  return (
    <Swiper
      modules={[Navigation, Pagination, Autoplay]}
      spaceBetween={50}
      slidesPerView={1}
      navigation
      pagination={{ clickable: true }}
      autoplay={{ delay: 3000, disableOnInteraction: false }}
      loop={true}
      className="w-full h-[400px]"
    >
      <SwiperSlide>
        <img src={slide1} alt="Slide 1" />
      </SwiperSlide>
      <SwiperSlide>
        <img src={slide2} alt="Slide 2" />
      </SwiperSlide>
    </Swiper>
  );
};

export default ImageCarousel;
