import React from "react";

const InfoPage = () =>{
    return (
        <h1 style={{fontSize:"50px"}}>Informasi Pendaftaran</h1>
    )
}
export default InfoPage;