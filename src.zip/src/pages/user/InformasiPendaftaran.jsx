const InformasiPendaftaran = () => {
    return (
        <div>
            <h1>INFORMASI PENDAFTARAN</h1>
        </div>
    )
}

export default InformasiPendaftaran;